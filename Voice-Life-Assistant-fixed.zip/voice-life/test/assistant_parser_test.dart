import 'package:flutter_test/flutter_test.dart';
import 'package:voice_life/data/reminder.dart';
import 'package:voice_life/services/assistant_parser.dart';

void main() {
  group('UzbekCommandParser', () {
    final now = DateTime(2026, 11, 4, 6);

    test('parses a daily spoken-number reminder', () {
      final draft = UzbekCommandParser.parse(
        'Har kuni soat sakkizda ingliz tilini eslat.',
        now: now,
      );

      expect(draft.recurrence, ReminderRecurrence.daily);
      expect(draft.title, 'Ingliz tilini');
      expect(draft.dueAt, DateTime(2026, 11, 4, 8));
      expect(draft.isCertain, isTrue);
    });

    test('parses tomorrow and an ASCII Uzbek apostrophe', () {
      final draft = UzbekCommandParser.parse(
        "Ertaga soat o'nda xamir qorishni eslat.",
        now: now,
      );

      expect(draft.dueAt, DateTime(2026, 11, 5, 10));
      expect(draft.title, 'Xamir qorishni');
    });

    test('keeps today explicit when its time has already passed', () {
      final draft = UzbekCommandParser.parse(
        'Bugun soat yettida ovqat tayyorlashni eslat.',
        now: now,
      );

      expect(draft.dueAt, DateTime(2026, 11, 4, 7));
      expect(draft.title, 'Ovqat tayyorlashni');
    });

    test('matches whole weekday names and chooses the next selected day', () {
      final draft = UzbekCommandParser.parse(
        'Har dushanba soat 08:30 da yugurishni eslat.',
        now: now,
      );

      expect(draft.recurrence, ReminderRecurrence.weekly);
      expect(draft.weekdays, [DateTime.monday]);
      expect(draft.dueAt.weekday, DateTime.monday);
      expect(draft.dueAt, DateTime(2026, 11, 9, 8, 30));
      expect(draft.title, 'Yugurishni');
    });

    test('moves a past daily occurrence to the next day', () {
      final draft = UzbekCommandParser.parse(
        'Har kuni soat sakkizda dori ichishni eslat.',
        now: DateTime(2026, 11, 4, 9),
      );

      expect(draft.dueAt, DateTime(2026, 11, 5, 8));
    });
  });
}
