import '../lib/data/reminder.dart';
import '../lib/services/assistant_parser.dart';

void main() {
  final now = DateTime(2026, 11, 4, 6);
  final daily = UzbekCommandParser.parse(
    'Har kuni soat sakkizda ingliz tilini eslat.',
    now: now,
  );
  _expect(daily.recurrence == ReminderRecurrence.daily, 'daily repeat');
  _expect(daily.dueAt.hour == 8 && daily.dueAt.minute == 0, 'spoken 8 o’clock');
  _expect(daily.title == 'Ingliz tilini', 'daily task title');
  _expect(daily.isCertain, 'daily command confidence');

  final tomorrow = UzbekCommandParser.parse(
    "Ertaga soat o'nda xamir qorishni eslat.",
    now: now,
  );
  _expect(
    tomorrow.dueAt.day == 5 && tomorrow.dueAt.hour == 10,
    'tomorrow at 10',
  );
  _expect(tomorrow.title == 'Xamir qorishni', 'tomorrow task title');

  final today = UzbekCommandParser.parse(
    'Bugun soat yettida ovqat tayyorlashni eslat.',
    now: now,
  );
  _expect(today.dueAt.day == 4 && today.dueAt.hour == 7, 'today at 7');
  _expect(today.title == 'Ovqat tayyorlashni', 'today task title');

  final weekly = UzbekCommandParser.parse(
    'Har dushanba soat 08:30 da yugurishni eslat.',
    now: now,
  );
  _expect(weekly.recurrence == ReminderRecurrence.weekly, 'weekly repeat');
  _expect(weekly.weekdays.contains(DateTime.monday), 'weekly weekday');
  _expect(
    weekly.dueAt.weekday == DateTime.monday,
    'next matching weekday: ${weekly.dueAt} (${weekly.dueAt.weekday})',
  );
  _expect(weekly.dueAt.hour == 8 && weekly.dueAt.minute == 30, 'numeric time');
  _expect(weekly.title == 'Yugurishni', 'weekly task title');

  final lateDaily = UzbekCommandParser.parse(
    'Har kuni soat sakkizda dori ichishni eslat.',
    now: DateTime(2026, 11, 4, 9),
  );
  _expect(
    lateDaily.dueAt.day == 5 && lateDaily.dueAt.hour == 8,
    'next daily time',
  );
}

void _expect(bool condition, String name) {
  if (!condition) throw StateError('Failed parser check: $name');
}
