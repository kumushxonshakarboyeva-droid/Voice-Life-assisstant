package com.voicelife.reminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.util.Locale

class MainActivity : FlutterActivity(), TextToSpeech.OnInitListener {
    private var channel: MethodChannel? = null
    private var tts: TextToSpeech? = null
    private var ttsStatus: Int? = null
    private val pendingVoiceResults = mutableListOf<MethodChannel.Result>()
    private var pendingPreview: Pair<String, MethodChannel.Result>? = null
    private var pendingNotificationResult: MethodChannel.Result? = null
    private var pendingExactAlarmResult: MethodChannel.Result? = null
    private var pendingSpeechResult: MethodChannel.Result? = null
    private var pendingSpeechLocale = "uz-UZ"
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var backupResult: MethodChannel.Result? = null
    private var backupIsRestore = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL_NAME,
        ).also { methodChannel ->
            methodChannel.setMethodCallHandler(::handleMethodCall)
        }
        ReminderNotifications.ensureChannel(this)
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        ttsStatus = status
        val waitingVoices = pendingVoiceResults.toList()
        pendingVoiceResults.clear()
        waitingVoices.forEach { replyVoices(it) }
        pendingPreview?.let { (text, result) ->
            pendingPreview = null
            playPreview(text, result)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_NOTIFICATION_PERMISSION -> {
                pendingNotificationResult?.success(notificationPermissionGranted())
                pendingNotificationResult = null
            }
            REQUEST_SPEECH_PERMISSION -> {
                val result = pendingSpeechResult
                pendingSpeechResult = null
                if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                    if (result != null) beginSpeechRecognition(pendingSpeechLocale, result)
                } else {
                    result?.error("PERMISSION_DENIED", "Microphone permission was denied", null)
                }
            }
        }
    }

    @Deprecated("Deprecated by Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_EXACT_ALARM_SETTINGS -> {
                pendingExactAlarmResult?.success(exactAlarmPermissionGranted())
                pendingExactAlarmResult = null
            }
            REQUEST_BACKUP_EXPORT,
            REQUEST_BACKUP_IMPORT -> finishBackupActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        destroySpeechRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        pendingVoiceResults.clear()
        pendingPreview = null
        pendingNotificationResult = null
        pendingExactAlarmResult = null
        pendingSpeechResult = null
        backupResult = null
        channel?.setMethodCallHandler(null)
        super.onDestroy()
    }

    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "initialize" -> {
                    ReminderNotifications.ensureChannel(this)
                    if (call.argumentMap()["reschedule"] == true) {
                        ReminderAlarmScheduler(this).cancelAllAndReschedule()
                    }
                    result.success(capabilities())
                }
                "listReminders" -> result.success(ReminderDatabase.get(this).listReminders())
                "saveReminder" -> saveReminder(call, result)
                "deleteReminder" -> deleteReminder(call, result)
                "completeReminder" -> completeReminder(call, result)
                "snoozeReminder" -> snoozeReminder(call, result)
                "rescheduleMissed" -> rescheduleMissed(call, result)
                "getSettings" -> result.success(ReminderDatabase.get(this).getSettings())
                "saveSettings" -> {
                    ReminderDatabase.get(this).saveSettings(call.argumentMap())
                    result.success(null)
                }
                "getVoices" -> {
                    if (ttsStatus == null) pendingVoiceResults += result else replyVoices(result)
                }
                "getAlarmStatus" -> result.success(capabilities())
                "requestNotificationPermission" -> requestNotificationPermission(result)
                "requestExactAlarmPermission" -> requestExactAlarmPermission(result)
                "openBatterySettings" -> openBatterySettings(result)
                "openTtsSettings" -> openTtsSettings(result)
                "previewSpeech" -> {
                    val text = call.argumentMap()["text"]?.toString().orEmpty()
                    if (text.isBlank()) {
                        result.error("EMPTY_TEXT", "Preview text is empty", null)
                    } else if (ttsStatus == null) {
                        pendingPreview = text to result
                    } else {
                        playPreview(text, result)
                    }
                }
                "listenForCommand" -> requestSpeechRecognition(
                    call.argumentMap()["locale"]?.toString() ?: "uz-UZ",
                    result,
                )
                "getStatistics" -> result.success(ReminderDatabase.get(this).statistics())
                "exportBackup" -> launchBackup(restore = false, result = result)
                "importBackup" -> launchBackup(restore = true, result = result)
                else -> result.notImplemented()
            }
        } catch (error: Exception) {
            result.error("VOICE_LIFE_ERROR", error.message ?: "Android operation failed", null)
        }
    }

    private fun saveReminder(call: MethodCall, result: MethodChannel.Result) {
        val input = call.argumentMap()
        val id = input["id"]?.toString()
        if (id.isNullOrBlank()) {
            result.error("INVALID_REMINDER", "Reminder id is required", null)
            return
        }
        val scheduler = ReminderAlarmScheduler(this)
        val saved = ReminderDatabase.get(this).saveReminder(input)
        scheduler.cancelMain(id)
        scheduler.cancelSnooze(id)
        ReminderNotifications.cancel(this, id)
        ReminderSpeechService.removeIfRunning(id)
        scheduler.schedule(saved)
        result.success(saved)
    }

    private fun deleteReminder(call: MethodCall, result: MethodChannel.Result) {
        val id = call.argumentMap()["id"]?.toString()
        if (id.isNullOrBlank()) {
            result.error("INVALID_REMINDER", "Reminder id is required", null)
            return
        }
        val scheduler = ReminderAlarmScheduler(this)
        scheduler.cancelMain(id)
        scheduler.cancelSnooze(id)
        ReminderDatabase.get(this).deleteReminder(id)
        ReminderNotifications.cancel(this, id)
        ReminderSpeechService.removeIfRunning(id)
        result.success(null)
    }

    private fun completeReminder(call: MethodCall, result: MethodChannel.Result) {
        val id = call.argumentMap()["id"]?.toString()
        if (id.isNullOrBlank()) {
            result.error("INVALID_REMINDER", "Reminder id is required", null)
            return
        }
        val scheduler = ReminderAlarmScheduler(this)
        scheduler.cancelSnooze(id)
        val database = ReminderDatabase.get(this)
        database.completeReminder(id)
        val updated = database.getReminder(id)
        if (updated?.get("status") == "pending") {
            scheduler.cancelMain(id)
            scheduler.schedule(updated)
        } else {
            scheduler.cancelMain(id)
        }
        ReminderNotifications.cancel(this, id)
        ReminderSpeechService.removeIfRunning(id)
        result.success(null)
    }

    private fun snoozeReminder(call: MethodCall, result: MethodChannel.Result) {
        val arguments = call.argumentMap()
        val id = arguments["id"]?.toString()
        if (id.isNullOrBlank()) {
            result.error("INVALID_REMINDER", "Reminder id is required", null)
            return
        }
        val minutes = (arguments["minutes"] as? Number)?.toInt()?.coerceIn(1, 120) ?: 10
        val database = ReminderDatabase.get(this)
        val current = database.getReminder(id)
        if (current?.get("status") != "ringing" && current?.get("status") != "snoozed") {
            result.error("NOT_RINGING", "Only an active reminder can be snoozed", null)
            return
        }
        val reminder = database.snoozeReminder(id, minutes)
        if (reminder == null) {
            result.error("NOT_FOUND", "Reminder was not found", null)
            return
        }
        val until = (reminder["snoozedUntilMs"] as? Number)?.toLong()
            ?: System.currentTimeMillis() + minutes * 60_000L
        ReminderAlarmScheduler(this).scheduleSnooze(id, until)
        ReminderNotifications.cancel(this, id)
        ReminderSpeechService.removeIfRunning(id)
        result.success(reminder)
    }

    private fun rescheduleMissed(call: MethodCall, result: MethodChannel.Result) {
        val arguments = call.argumentMap()
        val id = arguments["id"]?.toString()
        val dueAt = (arguments["dueAtMs"] as? Number)?.toLong()
        if (id.isNullOrBlank() || dueAt == null) {
            result.error("INVALID_REMINDER", "Reminder id and time are required", null)
            return
        }
        val reminder = ReminderDatabase.get(this).rescheduleMissed(id, dueAt)
        if (reminder == null) {
            result.error("NOT_FOUND", "Reminder was not found", null)
            return
        }
        ReminderAlarmScheduler(this).schedule(reminder)
        result.success(reminder)
    }

    private fun requestNotificationPermission(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < 33 || notificationPermissionGranted()) {
            result.success(notificationPermissionGranted())
            return
        }
        if (pendingNotificationResult != null) {
            result.error("PERMISSION_PENDING", "A permission request is already open", null)
            return
        }
        pendingNotificationResult = result
        requestPermissions(
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            REQUEST_NOTIFICATION_PERMISSION,
        )
    }

    private fun requestExactAlarmPermission(result: MethodChannel.Result) {
        val intent = ReminderAlarmScheduler(this).exactAlarmSettingsIntent()
        if (intent == null) {
            result.success(true)
            return
        }
        pendingExactAlarmResult = result
        try {
            startActivityForResult(intent, REQUEST_EXACT_ALARM_SETTINGS)
        } catch (error: Exception) {
            pendingExactAlarmResult = null
            result.error("SETTINGS_UNAVAILABLE", error.message, null)
        }
    }

    private fun openBatterySettings(result: MethodChannel.Result) {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            }
            startActivity(intent)
            result.success(null)
        } catch (error: Exception) {
            result.error("SETTINGS_UNAVAILABLE", error.message, null)
        }
    }

    private fun openTtsSettings(result: MethodChannel.Result) {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            result.success(null)
        } catch (error: Exception) {
            result.error("SETTINGS_UNAVAILABLE", error.message, null)
        }
    }

    private fun replyVoices(result: MethodChannel.Result) {
        val engine = tts
        if (ttsStatus != TextToSpeech.SUCCESS || engine == null) {
            result.success(emptyList<Map<String, Any>>())
            return
        }
        val defaultName = engine.defaultVoice?.name
        val voices = (engine.voices ?: emptySet()).filter { voice ->
            !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }.sortedWith(
            compareBy<Voice> { it.locale.displayName.lowercase(Locale.ROOT) }
                .thenByDescending { it.quality },
        ).map { voice ->
            mapOf(
                "name" to voice.name,
                "localeTag" to voice.locale.toLanguageTag(),
                "language" to voice.locale.language,
                "quality" to voice.quality,
                "requiresNetwork" to voice.isNetworkConnectionRequired,
                "isDefault" to (voice.name == defaultName),
            )
        }
        result.success(voices)
    }

    private fun playPreview(text: String, result: MethodChannel.Result) {
        val engine = tts
        if (ttsStatus != TextToSpeech.SUCCESS || engine == null) {
            result.error("TTS_UNAVAILABLE", "Android TTS engine is not ready", null)
            return
        }
        val settings = ReminderDatabase.get(this).getSettings()
        val localeTag = settings["speechLocale"]?.toString() ?: "uz-UZ"
        val locale = Locale.forLanguageTag(localeTag)
        val voices = (engine.voices ?: emptySet()).filter { voice ->
            voice.locale.language.equals(locale.language, ignoreCase = true) &&
                !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
        if (voices.isEmpty()) {
            result.error(
                "VOICE_UNAVAILABLE",
                "No installed TTS voice for $localeTag. No other language voice was substituted.",
                null,
            )
            return
        }
        val selected = settings["voiceName"]?.toString().orEmpty()
        val voice = voices.firstOrNull { it.name == selected }
            ?: engine.defaultVoice?.takeIf { default ->
                voices.any { it.name == default.name }
            }
            ?: voices.maxByOrNull { it.quality }
        if (voice == null) {
            val languageStatus = engine.setLanguage(locale)
            if (languageStatus == TextToSpeech.LANG_MISSING_DATA ||
                languageStatus == TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                result.error("VOICE_UNAVAILABLE", "No TTS voice for $localeTag", null)
                return
            }
        }
        try {
            val previewIntent = Intent(this, ReminderSpeechService::class.java).apply {
                action = ReminderSpeechService.ACTION_PREVIEW
                putExtra(ReminderSpeechService.EXTRA_PREVIEW_TEXT, text.take(1000))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(previewIntent)
            } else {
                startService(previewIntent)
            }
            result.success(null)
        } catch (error: Exception) {
            result.error("TTS_FAILED", error.message ?: "Could not start voice preview", null)
        }
    }

    private fun requestSpeechRecognition(locale: String, result: MethodChannel.Result) {
        if (pendingSpeechResult != null) {
            result.error("LISTENING", "Speech recognition is already active", null)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            result.error("RECOGNIZER_UNAVAILABLE", "No Android speech recognizer is installed", null)
            return
        }
        pendingSpeechLocale = locale
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingSpeechResult = result
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_SPEECH_PERMISSION,
            )
            return
        }
        beginSpeechRecognition(locale, result)
    }

    private fun beginSpeechRecognition(locale: String, result: MethodChannel.Result) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            result.error("RECOGNIZER_UNAVAILABLE", "No Android speech recognizer is installed", null)
            return
        }
        destroySpeechRecognizer()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = recognizer
        pendingSpeechResult = result
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onError(error: Int) {
                finishSpeech(null)
            }

            override fun onResults(results: Bundle?) {
                val recognized = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                finishSpeech(recognized)
            }
        })
        val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer.startListening(request)
        mainHandler.postDelayed(
            { if (pendingSpeechResult === result) finishSpeech(null) },
            SPEECH_TIMEOUT_MS,
        )
    }

    private fun finishSpeech(text: String?) {
        val result = pendingSpeechResult ?: return
        pendingSpeechResult = null
        destroySpeechRecognizer()
        result.success(text?.take(1000))
    }

    private fun destroySpeechRecognizer() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
            // The recognizer may already have shut itself down.
        }
        speechRecognizer = null
    }

    private fun launchBackup(restore: Boolean, result: MethodChannel.Result) {
        val intent = if (restore) {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
            }
        } else {
            Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(
                    Intent.EXTRA_TITLE,
                    "voice-life-backup-${System.currentTimeMillis()}.json",
                )
            }
        }
        try {
            backupIsRestore = restore
            backupResult = result
            startActivityForResult(
                intent,
                if (restore) REQUEST_BACKUP_IMPORT else REQUEST_BACKUP_EXPORT,
            )
        } catch (error: Exception) {
            backupResult = null
            result.error("BACKUP_UNAVAILABLE", error.message, null)
        }
    }

    private fun finishBackupActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?,
    ) {
        val result = backupResult ?: return
        backupResult = null
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            result.success(false)
            return
        }
        try {
            val uri = data.data!!
            if (requestCode == REQUEST_BACKUP_EXPORT && !backupIsRestore) {
                contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(ReminderDatabase.get(this).exportJson().toByteArray(Charsets.UTF_8))
                } ?: error("Could not open backup destination")
                result.success(true)
            } else if (requestCode == REQUEST_BACKUP_IMPORT && backupIsRestore) {
                val json = contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readBytes()
                    require(bytes.size <= MAX_BACKUP_BYTES) { "Backup file is too large" }
                    bytes.toString(Charsets.UTF_8)
                } ?: error("Could not read backup file")
                ReminderDatabase.get(this).importJson(json)
                ReminderAlarmScheduler(this).cancelAllAndReschedule()
                result.success(true)
            } else {
                result.success(false)
            }
        } catch (error: Exception) {
            result.error("BACKUP_FAILED", error.message ?: "Backup operation failed", null)
        }
    }

    private fun capabilities(): Map<String, Any> = mapOf(
        "notificationGranted" to notificationPermissionGranted(),
        "exactAlarmGranted" to exactAlarmPermissionGranted(),
        "speechRecognitionAvailable" to SpeechRecognizer.isRecognitionAvailable(this),
    )

    private fun notificationPermissionGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun exactAlarmPermissionGranted(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()

    private fun MethodCall.argumentMap(): Map<*, *> =
        (arguments as? Map<*, *>) ?: emptyMap<Any, Any>()

    companion object {
        private const val CHANNEL_NAME = "com.voicelife.reminder/native"
        private const val REQUEST_NOTIFICATION_PERMISSION = 7011
        private const val REQUEST_SPEECH_PERMISSION = 7012
        private const val REQUEST_EXACT_ALARM_SETTINGS = 7013
        private const val REQUEST_BACKUP_EXPORT = 7014
        private const val REQUEST_BACKUP_IMPORT = 7015
        private const val SPEECH_TIMEOUT_MS = 45_000L
        private const val MAX_BACKUP_BYTES = 5 * 1024 * 1024
    }
}
