package com.voicelife.reminder

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class ReminderDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE reminders (
              id TEXT PRIMARY KEY NOT NULL,
              title TEXT NOT NULL,
              description TEXT NOT NULL DEFAULT '',
              due_at INTEGER NOT NULL,
              hour INTEGER NOT NULL,
              minute INTEGER NOT NULL,
              local_year INTEGER NOT NULL DEFAULT 1970,
              local_month INTEGER NOT NULL DEFAULT 1,
              local_day INTEGER NOT NULL DEFAULT 1,
              month_day INTEGER NOT NULL DEFAULT 1,
              recurrence TEXT NOT NULL DEFAULT 'none',
              weekdays TEXT NOT NULL DEFAULT '',
              category TEXT NOT NULL DEFAULT 'general',
              priority INTEGER NOT NULL DEFAULT 1,
              status TEXT NOT NULL DEFAULT 'pending',
              created_at INTEGER NOT NULL,
              updated_at INTEGER,
              triggered_at INTEGER,
              snoozed_until INTEGER,
              source TEXT NOT NULL DEFAULT 'text'
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE settings (
              key TEXT PRIMARY KEY NOT NULL,
              value TEXT NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE events (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              reminder_id TEXT NOT NULL,
              title TEXT NOT NULL,
              event_type TEXT NOT NULL,
              happened_at INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        insertDefaultSettings(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS events (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  reminder_id TEXT NOT NULL,
                  title TEXT NOT NULL,
                  event_type TEXT NOT NULL,
                  happened_at INTEGER NOT NULL
                )
                """.trimIndent(),
            )
            db.execSQL("ALTER TABLE reminders ADD COLUMN snoozed_until INTEGER")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE reminders ADD COLUMN local_year INTEGER NOT NULL DEFAULT 1970")
            db.execSQL("ALTER TABLE reminders ADD COLUMN local_month INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE reminders ADD COLUMN local_day INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE reminders ADD COLUMN month_day INTEGER NOT NULL DEFAULT 1")
            db.query("reminders", arrayOf("id", "due_at"), null, null, null, null, null)
                .use { cursor ->
                    while (cursor.moveToNext()) {
                        val id = cursor.getString(0)
                        val calendar = Calendar.getInstance().apply {
                            timeInMillis = cursor.getLong(1)
                        }
                        db.update(
                            "reminders",
                            ContentValues().apply {
                                put("local_year", calendar.get(Calendar.YEAR))
                                put("local_month", calendar.get(Calendar.MONTH) + 1)
                                put("local_day", calendar.get(Calendar.DAY_OF_MONTH))
                                put("month_day", calendar.get(Calendar.DAY_OF_MONTH))
                            },
                            "id = ?",
                            arrayOf(id),
                        )
                    }
                }
        }
    }

    fun saveReminder(input: Map<*, *>, restore: Boolean = false): Map<String, Any?> {
        val id = input["id"]?.toString()?.trim().orEmpty()
        val title = input["title"]?.toString()?.trim().orEmpty()
        require(id.isNotEmpty()) { "Reminder id is required" }
        require(title.isNotEmpty()) { "Reminder title is required" }
        require(title.length <= 120) { "Reminder title is too long" }

        val dueAt = input.long("dueAtMs", System.currentTimeMillis())
        val calendar = Calendar.getInstance().apply { timeInMillis = dueAt }
        val recurrence = input["recurrence"]?.toString()
            ?.takeIf { it in setOf("none", "daily", "weekly", "monthly") } ?: "none"
        val weekdays = (input["weekdays"] as? List<*>)
            ?.mapNotNull { (it as? Number)?.toInt() }
            ?.filter { it in Calendar.SUNDAY..Calendar.SATURDAY }
            ?.distinct()
            ?.sorted()
            .orEmpty()
        require(recurrence != "weekly" || weekdays.isNotEmpty()) {
            "Choose at least one weekday for a weekly reminder"
        }

        val values = ContentValues().apply {
            put("id", id)
            put("title", title)
            put("description", input["description"]?.toString().orEmpty().take(500))
            put("due_at", dueAt)
            val hour = input.int("hour", calendar.get(Calendar.HOUR_OF_DAY)).coerceIn(0, 23)
            val minute = input.int("minute", calendar.get(Calendar.MINUTE)).coerceIn(0, 59)
            val localYear = input.int("localYear", calendar.get(Calendar.YEAR))
            val localMonth = input.int("localMonth", calendar.get(Calendar.MONTH) + 1)
                .coerceIn(1, 12)
            val localDay = input.int("localDay", calendar.get(Calendar.DAY_OF_MONTH))
                .coerceIn(1, 31)
            put("hour", hour)
            put("minute", minute)
            put("local_year", localYear)
            put("local_month", localMonth)
            put("local_day", localDay)
            put(
                "month_day",
                input.int("monthDay", localDay).coerceIn(1, 31),
            )
            put("recurrence", recurrence)
            put("weekdays", weekdays.joinToString(","))
            put("category", input["category"]?.toString()
                ?.takeIf { it in setOf("general", "work", "personal", "health", "study") }
                ?: "general")
            put("priority", input.int("priority", 1).coerceIn(0, 2))
            val restoredStatus = input["status"]?.toString()
                ?.takeIf { restore && it in setOf("pending", "ringing", "snoozed", "completed", "missed") }
            put("status", restoredStatus ?: "pending")
            put("created_at", input.long("createdAtMs", System.currentTimeMillis()))
            put("updated_at", System.currentTimeMillis())
            val triggeredAt = (input["triggeredAtMs"] as? Number)?.toLong()
            val snoozedUntil = (input["snoozedUntilMs"] as? Number)?.toLong()
            if (restore && triggeredAt != null) put("triggered_at", triggeredAt) else putNull("triggered_at")
            if (restore && restoredStatus == "snoozed" && snoozedUntil != null) {
                put("snoozed_until", snoozedUntil)
            } else {
                putNull("snoozed_until")
            }
            put("source", input["source"]?.toString()
                ?.takeIf { it == "text" || it == "voice" } ?: "text")
        }
        writableDatabase.insertWithOnConflict(
            "reminders",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE,
        )
        return getReminder(id) ?: error("Saved reminder could not be read back")
    }

    fun getReminder(id: String): Map<String, Any?>? {
        readableDatabase.query(
            "reminders",
            null,
            "id = ?",
            arrayOf(id),
            null,
            null,
            null,
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursor.toReminderMap() else null
        }
    }

    fun listReminders(): List<Map<String, Any?>> {
        val output = mutableListOf<Map<String, Any?>>()
        readableDatabase.query(
            "reminders",
            null,
            null,
            null,
            null,
            null,
            "due_at ASC",
        ).use { cursor ->
            while (cursor.moveToNext()) output += cursor.toReminderMap()
        }
        return output
    }

    fun deleteReminder(id: String) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("reminders", "id = ?", arrayOf(id))
            writableDatabase.delete("events", "reminder_id = ?", arrayOf(id))
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    fun markTriggered(id: String, snoozed: Boolean): Map<String, Any?>? {
        val reminder = getReminder(id) ?: return null
        val now = System.currentTimeMillis()
        val values = ContentValues().apply {
            put("status", "ringing")
            put("triggered_at", now)
            put("updated_at", now)
            if (snoozed) putNull("snoozed_until")
        }
        if (!snoozed && reminder["recurrence"] != "none") {
            val next = nextOccurrence(reminder, now)
            values.put("due_at", next)
            putLocalDate(values, next)
        }
        writableDatabase.update("reminders", values, "id = ?", arrayOf(id))
        return getReminder(id)
    }

    fun completeReminder(id: String) {
        val reminder = getReminder(id) ?: return
        val now = System.currentTimeMillis()
        writableDatabase.beginTransaction()
        try {
            insertEvent(id, reminder["title"].toString(), "completed", now)
            val status = if (reminder["recurrence"] == "none") "completed" else "pending"
            writableDatabase.update(
                "reminders",
                ContentValues().apply {
                    put("status", status)
                    put("updated_at", now)
                },
                "id = ?",
                arrayOf(id),
            )
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    fun snoozeReminder(id: String, minutes: Int): Map<String, Any?>? {
        val reminder = getReminder(id) ?: return null
        val now = System.currentTimeMillis()
        writableDatabase.beginTransaction()
        try {
            insertEvent(id, reminder["title"].toString(), "snoozed", now)
            writableDatabase.update(
                "reminders",
                ContentValues().apply {
                    put("status", "snoozed")
                    put("updated_at", now)
                    put("snoozed_until", now + minutes.coerceIn(1, 120) * 60_000L)
                },
                "id = ?",
                arrayOf(id),
            )
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
        return getReminder(id)
    }

    fun markMissed(id: String): Map<String, Any?>? {
        val reminder = getReminder(id) ?: return null
        val now = System.currentTimeMillis()
        val recurring = reminder["recurrence"] != "none"
        writableDatabase.beginTransaction()
        try {
            insertEvent(id, reminder["title"].toString(), "missed", now)
            val values = ContentValues().apply {
                put("status", if (recurring) "pending" else "missed")
                put("updated_at", now)
                if (recurring) {
                    val next = nextOccurrence(reminder, now)
                    put("due_at", next)
                    putLocalDate(this, next)
                }
            }
            writableDatabase.update("reminders", values, "id = ?", arrayOf(id))
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
        return getReminder(id)
    }

    fun rescheduleMissed(id: String, dueAt: Long): Map<String, Any?>? {
        val reminder = getReminder(id) ?: return null
        val calendar = Calendar.getInstance().apply { timeInMillis = dueAt }
        writableDatabase.update(
            "reminders",
            ContentValues().apply {
                put("due_at", dueAt)
                put("hour", calendar.get(Calendar.HOUR_OF_DAY))
                put("minute", calendar.get(Calendar.MINUTE))
                put("local_year", calendar.get(Calendar.YEAR))
                put("local_month", calendar.get(Calendar.MONTH) + 1)
                put("local_day", calendar.get(Calendar.DAY_OF_MONTH))
                put("month_day", calendar.get(Calendar.DAY_OF_MONTH))
                put("status", "pending")
                put("updated_at", System.currentTimeMillis())
                putNull("triggered_at")
                putNull("snoozed_until")
            },
            "id = ?",
            arrayOf(id),
        )
        return getReminder(id)
    }

    fun markLongOverdue() {
        val cutoff = System.currentTimeMillis() - OVERDUE_GRACE_MS
        val ids = mutableListOf<String>()
        readableDatabase.query(
            "reminders",
            arrayOf("id"),
            """
            due_at < ? AND (
              status = 'pending' OR (status = 'ringing' AND recurrence != 'none')
            )
            """.trimIndent(),
            arrayOf(cutoff.toString()),
            null,
            null,
            null,
        ).use { cursor ->
            while (cursor.moveToNext()) ids += cursor.getString(0)
        }
        ids.forEach { markMissed(it) }
    }

    fun recomputeWallClockSchedules() {
        val now = System.currentTimeMillis()
        listReminders()
            .filter { reminder ->
                val status = reminder["status"]
                val recurring = reminder["recurrence"] != "none"
                status == "pending" ||
                    (recurring && status in setOf("ringing", "snoozed"))
            }
            .forEach { reminder ->
                val recurrence = reminder["recurrence"]?.toString() ?: "none"
                val dueAt = if (recurrence == "none") {
                    val year = (reminder["localYear"] as? Number)?.toInt() ?: return@forEach
                    val month = (reminder["localMonth"] as? Number)?.toInt() ?: return@forEach
                    val day = (reminder["localDay"] as? Number)?.toInt() ?: return@forEach
                    Calendar.getInstance().apply {
                        clear()
                        set(
                            year,
                            month - 1,
                            day,
                            (reminder["hour"] as? Number)?.toInt() ?: 9,
                            (reminder["minute"] as? Number)?.toInt() ?: 0,
                        )
                    }.timeInMillis
                } else {
                    nextOccurrence(reminder, now)
                }
                writableDatabase.update(
                    "reminders",
                    ContentValues().apply {
                        put("due_at", dueAt)
                        putLocalDate(this, dueAt)
                        put("updated_at", now)
                    },
                    "id = ?",
                    arrayOf(reminder["id"].toString()),
                )
            }
    }

    fun getSettings(): Map<String, Any> {
        val values = mutableMapOf<String, String>()
        readableDatabase.query("settings", null, null, null, null, null, null)
            .use { cursor ->
                while (cursor.moveToNext()) {
                    values[cursor.getString(cursor.getColumnIndexOrThrow("key"))] =
                        cursor.getString(cursor.getColumnIndexOrThrow("value"))
                }
            }
        return mapOf(
            "uiLanguage" to values["uiLanguage"].orDefault("uz"),
            "speechLocale" to values["speechLocale"].orDefault("uz-UZ"),
            "voiceName" to values["voiceName"].orDefault(""),
            "speechRate" to (values["speechRate"]?.toDoubleOrNull() ?: 0.92),
            "speechPitch" to (values["speechPitch"]?.toDoubleOrNull() ?: 1.0),
            "speechVolume" to (values["speechVolume"]?.toDoubleOrNull() ?: 1.0),
            "repeatCount" to (values["repeatCount"]?.toIntOrNull() ?: 1).coerceIn(1, 3),
            "snoozeMinutes" to (values["snoozeMinutes"]?.toIntOrNull() ?: 10)
                .coerceIn(1, 120),
            "themeMode" to values["themeMode"].orDefault("system"),
            "speakOnly" to (values["speakOnly"]?.toBooleanStrictOrNull() ?: true),
        )
    }

    fun saveSettings(input: Map<*, *>) {
        val defaults = getSettings().toMutableMap()
        input.forEach { (key, value) ->
            if (key != null && value != null) defaults[key.toString()] = value
        }
        val safe = mapOf(
            "uiLanguage" to (defaults["uiLanguage"] as? String)
                ?.takeIf { it in setOf("uz", "ru", "en") }.orDefault("uz"),
            "speechLocale" to (defaults["speechLocale"] as? String)
                ?.takeIf { it in setOf("uz-UZ", "ru-RU", "en-US") }.orDefault("uz-UZ"),
            "voiceName" to (defaults["voiceName"] as? String).orDefault(""),
            "speechRate" to ((defaults["speechRate"] as? Number)?.toDouble() ?: 0.92)
                .coerceIn(0.5, 1.5),
            "speechPitch" to ((defaults["speechPitch"] as? Number)?.toDouble() ?: 1.0)
                .coerceIn(0.5, 2.0),
            "speechVolume" to ((defaults["speechVolume"] as? Number)?.toDouble() ?: 1.0)
                .coerceIn(0.0, 1.0),
            "repeatCount" to ((defaults["repeatCount"] as? Number)?.toInt() ?: 1)
                .coerceIn(1, 3),
            "snoozeMinutes" to ((defaults["snoozeMinutes"] as? Number)?.toInt() ?: 10)
                .coerceIn(1, 120),
            "themeMode" to (defaults["themeMode"] as? String)
                ?.takeIf { it in setOf("system", "light", "dark") }.orDefault("system"),
            "speakOnly" to ((defaults["speakOnly"] as? Boolean) ?: true).toString(),
        )
        val database = writableDatabase
        database.beginTransaction()
        try {
            safe.forEach { (key, value) ->
                database.insertWithOnConflict(
                    "settings",
                    null,
                    ContentValues().apply {
                        put("key", key)
                        put("value", value.toString())
                    },
                    SQLiteDatabase.CONFLICT_REPLACE,
                )
            }
            database.setTransactionSuccessful()
        } finally {
            database.endTransaction()
        }
    }

    fun statistics(): Map<String, Int> {
        val completed = eventCount("completed")
        val missed = eventCount("missed")
        val active = listReminders().count { it["status"] == "pending" }
        return mapOf("completed" to completed, "missed" to missed, "active" to active)
    }

    fun exportJson(): String {
        val root = JSONObject()
        root.put("format", "voice-life-backup-v1")
        root.put("exportedAtMs", System.currentTimeMillis())
        root.put("settings", JSONObject(getSettings()))
        val rows = JSONArray()
        listReminders().forEach { rows.put(JSONObject(it)) }
        root.put("reminders", rows)
        val eventRows = JSONArray()
        readableDatabase.query(
            "events",
            arrayOf("reminder_id", "title", "event_type", "happened_at"),
            null,
            null,
            null,
            null,
            "happened_at ASC",
        ).use { cursor ->
            while (cursor.moveToNext()) {
                eventRows.put(
                    JSONObject(
                        mapOf(
                            "reminderId" to cursor.getString(0),
                            "title" to cursor.getString(1),
                            "eventType" to cursor.getString(2),
                            "happenedAtMs" to cursor.getLong(3),
                        ),
                    ),
                )
            }
        }
        root.put("events", eventRows)
        return root.toString(2)
    }

    fun importJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "voice-life-backup-v1") {
            "Unsupported backup file"
        }
        val reminderArray = root.optJSONArray("reminders") ?: JSONArray()
        require(reminderArray.length() <= MAX_BACKUP_REMINDERS) {
            "Backup contains too many reminders"
        }
        val eventsArray = root.optJSONArray("events") ?: JSONArray()
        require(eventsArray.length() <= MAX_BACKUP_EVENTS) {
            "Backup contains too many history entries"
        }
        val validRows = mutableListOf<Map<*, *>>()
        for (index in 0 until reminderArray.length()) {
            val reminder = reminderArray.getJSONObject(index)
            validRows += reminder.toMap()
        }
        val database = writableDatabase
        database.beginTransaction()
        try {
            database.delete("reminders", null, null)
            database.delete("events", null, null)
            validRows.forEach { row ->
                val reminder = row.toMutableMap()
                val weekdays = when (val value = reminder["weekdays"]) {
                    is JSONArray -> (0 until value.length()).map { value.optInt(it) }
                    is List<*> -> value.mapNotNull { (it as? Number)?.toInt() }
                    else -> emptyList()
                }
                reminder["weekdays"] = weekdays
                saveReminder(reminder, restore = true)
            }
            for (index in 0 until eventsArray.length()) {
                val event = eventsArray.getJSONObject(index)
                val eventType = event.optString("eventType")
                if (eventType !in setOf("completed", "missed", "snoozed")) continue
                database.insert(
                    "events",
                    null,
                    ContentValues().apply {
                        put("reminder_id", event.optString("reminderId"))
                        put("title", event.optString("title").take(120))
                        put("event_type", eventType)
                        put("happened_at", event.optLong("happenedAtMs"))
                    },
                )
            }
            val settings = root.optJSONObject("settings")
            if (settings != null) saveSettings(settings.toMap())
            database.setTransactionSuccessful()
        } finally {
            database.endTransaction()
        }
    }

    private fun insertEvent(id: String, title: String, type: String, at: Long) {
        writableDatabase.insert(
            "events",
            null,
            ContentValues().apply {
                put("reminder_id", id)
                put("title", title)
                put("event_type", type)
                put("happened_at", at)
            },
        )
    }

    private fun eventCount(type: String): Int {
        readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM events WHERE event_type = ?",
            arrayOf(type),
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }
    }

    private fun nextOccurrence(reminder: Map<String, Any?>, after: Long): Long {
        val hour = (reminder["hour"] as? Number)?.toInt() ?: 9
        val minute = (reminder["minute"] as? Number)?.toInt() ?: 0
        val recurrence = reminder["recurrence"]?.toString() ?: "none"
        val weekdays = reminder["weekdays"] as? List<*> ?: emptyList<Any>()
        val selectedDays = weekdays.mapNotNull { (it as? Number)?.toInt() }.toSet()
        val anchor = Calendar.getInstance().apply {
            timeInMillis = (reminder["dueAtMs"] as? Number)?.toLong() ?: after
        }
        val anchorDay = (reminder["monthDay"] as? Number)?.toInt()
            ?: anchor.get(Calendar.DAY_OF_MONTH)
        val now = Calendar.getInstance().apply { timeInMillis = after }

        return when (recurrence) {
            "daily" -> {
                val candidate = (now.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= after) add(Calendar.DAY_OF_YEAR, 1)
                }
                candidate.timeInMillis
            }
            "weekly" -> {
                for (offset in 0..7) {
                    val candidate = (now.clone() as Calendar).apply {
                        add(Calendar.DAY_OF_YEAR, offset)
                        set(Calendar.HOUR_OF_DAY, hour)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    val calendarWeekday = candidate.get(Calendar.DAY_OF_WEEK)
                    val isoWeekday = if (calendarWeekday == Calendar.SUNDAY) {
                        7
                    } else {
                        calendarWeekday - 1
                    }
                    if (isoWeekday in selectedDays &&
                        candidate.timeInMillis > after
                    ) return candidate.timeInMillis
                }
                (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
            }
            "monthly" -> {
                for (offset in 0..24) {
                    val candidate = (now.clone() as Calendar).apply {
                        set(Calendar.DAY_OF_MONTH, 1)
                        add(Calendar.MONTH, offset)
                        val day = anchorDay.coerceAtMost(getActualMaximum(Calendar.DAY_OF_MONTH))
                        set(Calendar.DAY_OF_MONTH, day)
                        set(Calendar.HOUR_OF_DAY, hour)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    if (candidate.timeInMillis > after) return candidate.timeInMillis
                }
                (now.clone() as Calendar).apply { add(Calendar.MONTH, 1) }.timeInMillis
            }
            else -> after
        }
    }

    private fun insertDefaultSettings(db: SQLiteDatabase) {
        val defaults = mapOf(
            "uiLanguage" to "uz",
            "speechLocale" to "uz-UZ",
            "voiceName" to "",
            "speechRate" to "0.92",
            "speechPitch" to "1.0",
            "speechVolume" to "1.0",
            "repeatCount" to "1",
            "snoozeMinutes" to "10",
            "themeMode" to "system",
            "speakOnly" to "true",
        )
        defaults.forEach { (key, value) ->
            db.insert(
                "settings",
                null,
                ContentValues().apply {
                    put("key", key)
                    put("value", value)
                },
            )
        }
    }

    private fun Cursor.toReminderMap(): Map<String, Any?> {
        val dayText = getString(getColumnIndexOrThrow("weekdays"))
        val days = dayText.split(',').mapNotNull { it.toIntOrNull() }
        return mapOf(
            "id" to getString(getColumnIndexOrThrow("id")),
            "title" to getString(getColumnIndexOrThrow("title")),
            "description" to getString(getColumnIndexOrThrow("description")),
            "dueAtMs" to getLong(getColumnIndexOrThrow("due_at")),
            "hour" to getInt(getColumnIndexOrThrow("hour")),
            "minute" to getInt(getColumnIndexOrThrow("minute")),
            "localYear" to getInt(getColumnIndexOrThrow("local_year")),
            "localMonth" to getInt(getColumnIndexOrThrow("local_month")),
            "localDay" to getInt(getColumnIndexOrThrow("local_day")),
            "monthDay" to getInt(getColumnIndexOrThrow("month_day")),
            "recurrence" to getString(getColumnIndexOrThrow("recurrence")),
            "weekdays" to days,
            "category" to getString(getColumnIndexOrThrow("category")),
            "priority" to getInt(getColumnIndexOrThrow("priority")),
            "status" to getString(getColumnIndexOrThrow("status")),
            "createdAtMs" to getLong(getColumnIndexOrThrow("created_at")),
            "updatedAtMs" to getLongOrNull("updated_at"),
            "triggeredAtMs" to getLongOrNull("triggered_at"),
            "snoozedUntilMs" to getLongOrNull("snoozed_until"),
            "source" to getString(getColumnIndexOrThrow("source")),
        )
    }

    private fun Cursor.getLongOrNull(column: String): Long? {
        val index = getColumnIndexOrThrow(column)
        return if (isNull(index)) null else getLong(index)
    }

    private fun putLocalDate(values: ContentValues, millis: Long) {
        val calendar = Calendar.getInstance().apply { timeInMillis = millis }
        values.put("local_year", calendar.get(Calendar.YEAR))
        values.put("local_month", calendar.get(Calendar.MONTH) + 1)
        values.put("local_day", calendar.get(Calendar.DAY_OF_MONTH))
    }

    private fun Map<*, *>.int(key: String, default: Int): Int =
        (this[key] as? Number)?.toInt() ?: default

    private fun Map<*, *>.long(key: String, default: Long): Long =
        (this[key] as? Number)?.toLong() ?: default

    private fun String?.orDefault(default: String): String =
        this?.takeIf { it.isNotBlank() } ?: default

    private fun JSONObject.toMap(): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = get(key)
            output[key] = when (value) {
                JSONObject.NULL -> null
                is JSONObject -> value.toMap()
                is JSONArray -> value
                else -> value
            }
        }
        return output
    }

    companion object {
        private const val DATABASE_NAME = "voice_life.db"
        private const val DATABASE_VERSION = 3
        private const val OVERDUE_GRACE_MS = 60 * 60 * 1000L
        private const val MAX_BACKUP_REMINDERS = 10000
        private const val MAX_BACKUP_EVENTS = 50000

        @Volatile
        private var instance: ReminderDatabase? = null

        fun get(context: Context): ReminderDatabase =
            instance ?: synchronized(this) {
                instance ?: ReminderDatabase(context).also { instance = it }
            }
    }
}
