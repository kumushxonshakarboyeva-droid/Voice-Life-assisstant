package com.voicelife.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            AlarmManagerPermissionAction -> {
                val pending = goAsync()
                val recoverRinging =
                    action == Intent.ACTION_BOOT_COMPLETED ||
                        action == Intent.ACTION_MY_PACKAGE_REPLACED
                val recalculateWallClock =
                    action == Intent.ACTION_TIME_CHANGED ||
                        action == Intent.ACTION_TIMEZONE_CHANGED
                Thread {
                    try {
                        ReminderNotifications.ensureChannel(context)
                        if (recalculateWallClock) {
                            ReminderDatabase.get(context).recomputeWallClockSchedules()
                        }
                        ReminderAlarmScheduler(context)
                            .cancelAllAndReschedule(recoverRinging = recoverRinging)
                    } finally {
                        pending.finish()
                    }
                }.start()
            }
        }
    }

    companion object {
        private const val AlarmManagerPermissionAction =
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED"
    }
}
