package com.voicelife.reminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build

object ReminderNotifications {
    const val CHANNEL_ID = "voice_life_spoken_reminders"
    const val PREVIEW_NOTIFICATION_ID = 900_001
    private const val CHANNEL_NAME = "Spoken reminders"
    private const val CHANNEL_DESCRIPTION = "Silent visual notification while a reminder is spoken"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = CHANNEL_DESCRIPTION
            setSound(null, null)
            enableVibration(false)
            enableLights(false)
            lightColor = Color.TRANSPARENT
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)
    }

    fun buildReminder(
        context: Context,
        id: String,
        title: String,
        body: String,
        ongoing: Boolean,
    ): Notification {
        ensureChannel(context)
        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val contentIntent = launchIntent?.let {
            PendingIntent.getActivity(
                context,
                notificationId(id),
                it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }
        val done = actionIntent(context, id, ReminderActionReceiver.ACTION_DONE)
        val snooze = actionIntent(context, id, ReminderActionReceiver.ACTION_SNOOZE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        builder
            .setSmallIcon(R.drawable.ic_stat_voice_life)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(contentIntent)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(!ongoing)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setSound(null)
            .addAction(
                Notification.Action.Builder(
                    R.drawable.ic_action_check,
                    context.getString(R.string.notification_done),
                    done,
                ).build(),
            )
            .addAction(
                Notification.Action.Builder(
                    R.drawable.ic_action_snooze,
                    context.getString(R.string.notification_snooze),
                    snooze,
                ).build(),
            )
        return builder.build()
    }

    fun showReminder(context: Context, id: String, title: String, body: String) {
        ensureChannel(context)
        manager(context).notify(
            notificationId(id),
            buildReminder(context, id, title, body, ongoing = false),
        )
    }

    fun showSpeechUnavailable(
        context: Context,
        id: String,
        title: String,
        localeTag: String,
    ) {
        ensureChannel(context)
        val notification = buildReminder(
            context,
            id,
            title,
            "$localeTag ovozi topilmadi. Boshqa til ovozi ishlatilmadi. Android TTS sozlamalarini tekshiring.",
            ongoing = false,
        )
        manager(context).notify(notificationId(id), notification)
    }

    fun showEngineFailure(context: Context, id: String, title: String) {
        ensureChannel(context)
        val notification = buildReminder(
            context,
            id,
            title,
            "TTS xizmati ishlamadi. Ovoz sozlamalarini tekshiring.",
            ongoing = false,
        )
        manager(context).notify(notificationId(id), notification)
    }

    fun buildPreview(context: Context, body: String, ongoing: Boolean): Notification =
        simpleNotice(
            context,
            title = context.getString(R.string.tts_preview_title),
            body = body,
            contentId = "preview",
            ongoing = ongoing,
        )

    fun showPreview(context: Context, body: String) {
        ensureChannel(context)
        manager(context).notify(
            PREVIEW_NOTIFICATION_ID,
            buildPreview(context, body, ongoing = false),
        )
    }

    fun cancelPreview(context: Context) {
        manager(context).cancel(PREVIEW_NOTIFICATION_ID)
    }

    fun cancel(context: Context, id: String) {
        manager(context).cancel(notificationId(id))
    }

    fun notificationId(id: String): Int = (id.hashCode() and 0x7fffffff).coerceAtLeast(1)

    private fun simpleNotice(
        context: Context,
        title: String,
        body: String,
        contentId: String,
        ongoing: Boolean = false,
    ): Notification {
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val content = intent?.let {
            PendingIntent.getActivity(
                context,
                notificationId(contentId),
                it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        builder
            .setSmallIcon(R.drawable.ic_stat_voice_life)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(content)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(!ongoing)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setSound(null)
        return builder.build()
    }

    private fun actionIntent(context: Context, id: String, action: String): PendingIntent {
        val intent = Intent(context, ReminderActionReceiver::class.java).apply {
            this.action = action
            putExtra(ReminderActionReceiver.EXTRA_REMINDER_ID, id)
        }
        val requestCode = notificationId(id) xor action.hashCode()
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun manager(context: Context): NotificationManager =
        context.getSystemService(NotificationManager::class.java)
}
