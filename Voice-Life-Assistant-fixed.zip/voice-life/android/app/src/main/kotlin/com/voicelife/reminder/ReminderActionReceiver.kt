package com.voicelife.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val actionIntent = intent ?: return
        val id = actionIntent.getStringExtra(EXTRA_REMINDER_ID) ?: return
        val pending = goAsync()
        Thread {
            try {
                val database = ReminderDatabase.get(context)
                val scheduler = ReminderAlarmScheduler(context)
                when (actionIntent.action) {
                    ACTION_DONE -> {
                        database.completeReminder(id)
                        scheduler.cancelSnooze(id)
                        val updated = database.getReminder(id)
                        scheduler.cancelMain(id)
                        if (updated?.get("status") == "pending") {
                            scheduler.schedule(updated)
                        }
                        ReminderNotifications.cancel(context, id)
                        ReminderSpeechService.removeIfRunning(id)
                    }
                    ACTION_SNOOZE -> {
                        val settings = database.getSettings()
                        val minutes = (settings["snoozeMinutes"] as? Number)?.toInt() ?: 10
                        val reminder = database.snoozeReminder(id, minutes) ?: return@Thread
                        val until = (reminder["snoozedUntilMs"] as? Number)?.toLong()
                            ?: System.currentTimeMillis() + minutes * 60_000L
                        scheduler.scheduleSnooze(id, until)
                        ReminderNotifications.cancel(context, id)
                        ReminderSpeechService.removeIfRunning(id)
                    }
                }
            } catch (_: Exception) {
                // Keep notification actions isolated from process termination.
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_DONE = "com.voicelife.reminder.action.DONE"
        const val ACTION_SNOOZE = "com.voicelife.reminder.action.SNOOZE"
        const val EXTRA_REMINDER_ID = "reminderId"
    }
}
