package com.voicelife.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val alarmIntent = intent ?: return
        if (alarmIntent.action != ACTION_FIRE) return
        val id = alarmIntent.getStringExtra(EXTRA_REMINDER_ID) ?: return
        val snoozed = alarmIntent.getBooleanExtra(EXTRA_SNOOZED, false)
        val pending = goAsync()
        Thread {
            try {
                val database = ReminderDatabase.get(context)
                val triggered = database.markTriggered(id, snoozed) ?: return@Thread
                val scheduler = ReminderAlarmScheduler(context)
                if (snoozed) {
                    scheduler.cancelSnooze(id)
                } else if (triggered["recurrence"] != "none") {
                    scheduler.schedule(triggered)
                }

                val title = triggered["title"]?.toString().orEmpty()
                val description = triggered["description"]?.toString().orEmpty()
                val body = if (description.isBlank()) title else "$title. $description"
                ReminderNotifications.showReminder(context, id, title, body)
                val serviceIntent = Intent(context, ReminderSpeechService::class.java).apply {
                    action = ReminderSpeechService.ACTION_SPEAK
                    putExtra(ReminderSpeechService.EXTRA_REMINDER_ID, id)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            } catch (_: Exception) {
                // Alarm delivery must always release goAsync; a later app launch can surface state.
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_FIRE = "com.voicelife.reminder.action.FIRE"
        const val EXTRA_REMINDER_ID = "reminderId"
        const val EXTRA_SNOOZED = "snoozed"
    }
}
